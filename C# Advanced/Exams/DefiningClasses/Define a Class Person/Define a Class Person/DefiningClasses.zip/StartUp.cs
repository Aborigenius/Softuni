﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p1 = new Person("Pesho", 20);
            Person p2 = new Person("Gosho", 18);
            Person p3 = new Person("Stamat", 43);

            Person p4 = new Person();
            Person p5 = new Person(233);

            Console.WriteLine($"Name: {p3.Name} Age: {p3.Age}");
            Console.WriteLine($"Name: {p4.Name} Age: {p4.Age}");
            Console.WriteLine($"Name: {p5.Name} Age: {p5.Age}");
        }
    }
}
